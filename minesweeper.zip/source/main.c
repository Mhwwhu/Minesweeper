#include <stdio.h>
#include <stdlib.h>
#include "minesweeper.h" 

int main(int argc, char *argv[]) {
	FILE *fp = fopen("./config.txt", "r");
	if(!fp) {
		printf("File config.txt is not exist.\n");
		return -1;
	}
	int col, row, difficulty, mines;
	fscanf(fp, "difficulty: %d\n", &difficulty);
	switch(difficulty) {
		case 1:
			row = 9;
			col = 9;
			mines = 10;
			break;
		case 2:
			row = 16;
			col = 16;
			mines = 40;
			break;
			break;
		case 3:
			row = 16;
			col = 30;
			mines = 99;
			break;
		case 0:
			fscanf(fp, "colomn: %d\n", &col);
			fscanf(fp, "row: %d\n", &row);
			fscanf(fp, "mines: %d\n", &mines);
			if(col <= 0 || col >= 100 || row <= 0 || row >= 100 || mines < 0 || mines >= col*row) {
				printf("Please check your configure.\n");
				system("pause");
				return 1;
			}
			break;
		default:
			printf("Please check your configure.\n");
			system("pause");
			return 1;
	}
	
	Sleep(1000);
	
	start(col, row, mines);
	fclose(fp);
	return 0;
}
